package panels;

import connection.MySQL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.table.DefaultTableModel;
import util.RoundedUtil;
import util.SearchSuggestions;
import java.util.logging.Logger;
import java.util.logging.Level;
import util.LoggerUtil;

/**
 *
 * @author mgssr
 */
public class OtherProductsPanel extends javax.swing.JPanel {

    public static String totalProductCount;
    public static String totalStockCount;
    public static String lowStockCount;
    public static String totalSalesCount;
    public static String bestSellingProduct;
    public static String bestSellingProductCount;

    private static final Logger logger = LoggerUtil.getLogger(OtherProductsPanel.class);

    /**
     * Creates new form OtherProducts
     */
    public OtherProductsPanel() {
        security.Session.requireAdmin();
        initComponents();
        initCustomizations();
        manageBtn.addActionListener(e->{security.Session.requireAdmin();new panels.dialog.ManageProductsDialog(null,true).setVisible(true);refreshData();});
        SearchSuggestions.attach(searchTextField, searchBtn,
                "SELECT name FROM product WHERE name LIKE ? ORDER BY name LIMIT 8");
        initPanelData();
    }

    private void initCustomizations() {
        setPaddings();
        setBorderRadius();
    }

    private void setPaddings() {
        statsPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
    }

    private void setBorderRadius() {
        int radius = 15;

        RoundedUtil.roundedCorners(searchTextField, radius);
        RoundedUtil.roundedCorners(statsPanel, radius);
        RoundedUtil.roundedCorners(tableScrollPane, radius);
    }

//    ------------------------
    private void initPanelData() {
        setTableData();
        setStatsPanelData();
    }

    private void setTableData() {
        String query = "SELECT * "
                + "FROM product;";

        try {
            DefaultTableModel dtm = (DefaultTableModel) membersTable.getModel();
            dtm.setRowCount(0);
            ResultSet rs = MySQL.executeSearch(query);

            while (rs.next()) {
                Vector<String> dataRow = new Vector();
                dataRow.add(rs.getString("product_id"));
                dataRow.add(rs.getString("name"));
                dataRow.add(rs.getString("price"));
                dataRow.add(rs.getString("stock"));
                dataRow.add(rs.getString("description"));

                dtm.addRow(dataRow);
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "OtherProductsPanel.setTableData(){} caused an error!", e);
        }
    }

    private void setStatsPanelData() {
        String query = "SELECT * "
                + "FROM "
                + "(SELECT COUNT(product_id) AS total_products, "
                + "SUM(stock) AS total_stocks, "
                + "SUM(CASE WHEN stock <= 5 THEN 1 ELSE 0 END) AS low_stock_products "
                + "FROM product) AS product_stats LEFT JOIN "
                + " "
                + "(SELECT "
                + "(SELECT COUNT(*) FROM order_history WHERE date >= DATE_SUB(CURRENT_DATE(), INTERVAL DAYOFMONTH(CURRENT_DATE()) - 1 DAY)) AS total_orders, "
                + "name AS best_selling_product, "
                + "COUNT(*) AS best_selling_count "
                + "FROM (order_history LEFT JOIN product ON product_product_id = product_id) "
                + "GROUP BY product_product_id "
                + "ORDER BY best_selling_count DESC "
                + "LIMIT 1) AS order_stats ON 1=1;";

        try {
            ResultSet rs = MySQL.executeSearch(query);

            if (rs.next()) {
                totalProductCount = String.format("%02d", rs.getInt("total_products"));
                totalStockCount = String.format("%02d", rs.getInt("total_stocks"));
                lowStockCount = String.format("%02d", rs.getInt("low_stock_products"));
                totalSalesCount = String.format("%02d", rs.getInt("total_orders"));
                bestSellingProductCount = String.format("%02d", rs.getInt("best_selling_count"));
                bestSellingProduct = rs.getString("best_selling_product");
                if (bestSellingProduct == null) bestSellingProduct = "None";
            }
            totalProductsLabel.setText("Total Products:  " + totalProductCount);
            totalStocksLabel.setText("Total Stocks:  " + totalStockCount);
            lowStockProductsLabel.setText("Low Stock Products:  " + lowStockCount);
            totalSalesLabel.setText("Monthly Total Orders:  " + totalSalesCount);
            bestSellingProductsLabel.setText("Best Selling Product:  " + bestSellingProduct + " (" + bestSellingProductCount + ")");
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "OtherProductsPanel.setStatsPanelData(){} caused an error!", e);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        topPanel = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        searchTextField = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        searchBtn = new javax.swing.JButton();
        manageBtn = new javax.swing.JButton();
        statsPanel = new javax.swing.JPanel();
        totalProductsLabel = new javax.swing.JLabel();
        bestSellingProductsLabel = new javax.swing.JLabel();
        totalStocksLabel = new javax.swing.JLabel();
        psudoLabel1 = new javax.swing.JLabel();
        lowStockProductsLabel = new javax.swing.JLabel();
        psudoLabel2 = new javax.swing.JLabel();
        totalSalesLabel = new javax.swing.JLabel();
        tablePanel = new javax.swing.JPanel();
        tableScrollPane = new javax.swing.JScrollPane();
        membersTable = new javax.swing.JTable();

        topPanel.setBackground(new java.awt.Color(153, 255, 255));
        topPanel.setOpaque(false);
        topPanel.setLayout(new javax.swing.BoxLayout(topPanel, javax.swing.BoxLayout.LINE_AXIS));

        jPanel1.setPreferredSize(new java.awt.Dimension(450, 45));
        jPanel1.setLayout(new java.awt.GridLayout(1, 1));

        searchTextField.setFont(new java.awt.Font("Poppins Light", 0, 14)); // NOI18N
        searchTextField.setForeground(new java.awt.Color(204, 204, 204));
        searchTextField.setToolTipText("");
        jPanel1.add(searchTextField);

        topPanel.add(jPanel1);

        jPanel2.setLayout(new java.awt.GridLayout(1, 0));

        searchBtn.setFont(new java.awt.Font("Poppins SemiBold", 0, 14)); // NOI18N
        searchBtn.setText("Search");
        searchBtn.setPreferredSize(new java.awt.Dimension(100, 35));
        searchBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBtnActionPerformed(evt);
            }
        });
        jPanel2.add(searchBtn);

        manageBtn.setBackground(new java.awt.Color(255, 100, 0));
        manageBtn.setFont(new java.awt.Font("Poppins SemiBold", 0, 14)); // NOI18N
        manageBtn.setText("Manage");
        manageBtn.setPreferredSize(new java.awt.Dimension(100, 35));
        jPanel2.add(manageBtn);

        topPanel.add(jPanel2);

        statsPanel.setBackground(new java.awt.Color(51, 51, 51));
        statsPanel.setLayout(new java.awt.GridLayout(4, 2, 0, 5));

        totalProductsLabel.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        totalProductsLabel.setText("Total Products: ");
        statsPanel.add(totalProductsLabel);

        bestSellingProductsLabel.setFont(totalProductsLabel.getFont());
        bestSellingProductsLabel.setText("Best Selling Product: ");
        statsPanel.add(bestSellingProductsLabel);

        totalStocksLabel.setFont(totalProductsLabel.getFont());
        totalStocksLabel.setText("Total Stocks: ");
        statsPanel.add(totalStocksLabel);

        psudoLabel1.setFont(totalProductsLabel.getFont());
        statsPanel.add(psudoLabel1);

        lowStockProductsLabel.setFont(totalProductsLabel.getFont());
        lowStockProductsLabel.setText("Low Stock Products: ");
        statsPanel.add(lowStockProductsLabel);

        psudoLabel2.setFont(totalProductsLabel.getFont());
        statsPanel.add(psudoLabel2);

        totalSalesLabel.setFont(totalProductsLabel.getFont());
        totalSalesLabel.setText("Total Orders: ");
        statsPanel.add(totalSalesLabel);

        membersTable.setAutoCreateRowSorter(true);
        membersTable.setFont(new java.awt.Font("Poppins", 0, 14)); // NOI18N
        membersTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NAME", "PRICE", "STOCK", "DESCRIPTION"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        membersTable.setColumnSelectionAllowed(false);
        membersTable.setShowGrid(true);
        tableScrollPane.setViewportView(membersTable);

        javax.swing.GroupLayout tablePanelLayout = new javax.swing.GroupLayout(tablePanel);
        tablePanel.setLayout(tablePanelLayout);
        tablePanelLayout.setHorizontalGroup(
            tablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tableScrollPane)
        );
        tablePanelLayout.setVerticalGroup(
            tablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tablePanelLayout.createSequentialGroup()
                .addComponent(tableScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 361, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(topPanel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 774, Short.MAX_VALUE)
                    .addComponent(tablePanel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(statsPanel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(topPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(statsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tablePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void searchBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBtnActionPerformed
        security.Session.requireAdmin();
        getSearchResult();
    }//GEN-LAST:event_searchBtnActionPerformed

    private void getSearchResult() {
        String searchText = searchTextField.getText();

        if (!searchText.isBlank()) {
            searchTableData("%" + searchText + "%");
        } else {
            setTableData();
        }
    }

    private void searchTableData(String searchText) {
        String query = "SELECT * FROM product "
                + "WHERE "
                + "name LIKE ? OR "
                + "product_id LIKE ?;";

        try {
            DefaultTableModel dtm = (DefaultTableModel) membersTable.getModel();
            dtm.setRowCount(0);
            ResultSet rs = MySQL.executeSearch(query, searchText, searchText);

            while (rs.next()) {
                Vector<String> dataRow = new Vector();
                dataRow.add(rs.getString("product_id"));
                dataRow.add(rs.getString("name"));
                dataRow.add(rs.getString("price"));
                dataRow.add(rs.getString("stock"));
                dataRow.add(rs.getString("description"));

                dtm.addRow(dataRow);
            }
        } catch (SQLException e) {
            logger.log(Level.SEVERE, "OtherProductsPanel.searchTableData(){} caused an error!", e);
        }
    }

    public void refreshData() {
        setTableData();
        setStatsPanelData();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel bestSellingProductsLabel;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lowStockProductsLabel;
    private javax.swing.JButton manageBtn;
    private javax.swing.JTable membersTable;
    private javax.swing.JLabel psudoLabel1;
    private javax.swing.JLabel psudoLabel2;
    private javax.swing.JButton searchBtn;
    private javax.swing.JTextField searchTextField;
    private javax.swing.JPanel statsPanel;
    private javax.swing.JPanel tablePanel;
    private javax.swing.JScrollPane tableScrollPane;
    private javax.swing.JPanel topPanel;
    private javax.swing.JLabel totalProductsLabel;
    private javax.swing.JLabel totalSalesLabel;
    private javax.swing.JLabel totalStocksLabel;
    // End of variables declaration//GEN-END:variables
}

